import customtkinter as ctk
import csv

def launch_security_center_tab(parent_frame):
    for widget in parent_frame.winfo_children():
        widget.destroy()
    ctk.CTkLabel(parent_frame, text="🔒 Security Center", font=("Helvetica", 20)).pack(pady=10)

    try:
        with open("scan_history.csv", "r") as file:
            rows = list(csv.reader(file))
            for row in rows[-10:]:
                summary = f"{row[0]} — {row[1]} — {row[2]}"
                ctk.CTkLabel(parent_frame, text=summary, anchor="w").pack(fill="x", padx=10)
    except FileNotFoundError:
        ctk.CTkLabel(parent_frame, text="No scan history found.").pack()