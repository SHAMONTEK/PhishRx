import csv
from datetime import datetime

def save_scan_to_csv(severity, reasons, image_path):
    with open("scan_history.csv", "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([datetime.now().isoformat(), severity, "; ".join(reasons), image_path])