import customtkinter as ctk

def create_question_buttons(frame, callback):
    questions = [
        "Why was this flagged?",
        "Is this safe?",
        "How do I verify?",
        "What should I do?",
        "What are signs of phishing?"
    ]
    for q in questions:
        ctk.CTkButton(frame, text=q, command=lambda q=q: callback(q)).pack(side="left", padx=3)