def threat_breakdown_view(severity, reasons, full_text):
    risk_score = 10 * len(reasons)
    breakdown = f"🧠 Threat Breakdown\nSeverity: {severity}\nRisk Score: {risk_score}/100\n\nTriggers:\n"
    for r in reasons:
        breakdown += f" - {r}\n"
    if "http" in full_text:
        breakdown += "\n⚠️ URL Detected – Consider checking the domain carefully.\n"
    return breakdown