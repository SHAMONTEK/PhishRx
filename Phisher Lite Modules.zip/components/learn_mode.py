def launch_learn_mode(chatbox):
    chatbox.insert("end", "\n🎓 PHISH-ER Learn Mode Activated!\n")
    chatbox.insert("end", "Question: What’s a common phishing tactic?\n")
    chatbox.insert("end", "A) Asking for verification\nB) Sending money\nC) Telling jokes\n\n")
    chatbox.insert("end", "Type 'A', 'B', or 'C' to answer. More quizzes coming soon!\n")