import re

def find_suspicious_text(text):
    patterns = [
        (r"https?://\S+", "🔗 Contains URL"),
        (r"verify", "🔒 Verification Request"),
        (r"urgent", "⚠️ Urgency"),
        (r"account", "👤 Account Reference"),
        (r"reset", "🔐 Password Request")
    ]
    flagged = []
    for pattern, label in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        flagged.extend([(match, label) for match in matches])
    return flagged